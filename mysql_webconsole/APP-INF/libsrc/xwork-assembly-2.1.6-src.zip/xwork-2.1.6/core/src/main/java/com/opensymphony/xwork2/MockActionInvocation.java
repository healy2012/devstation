/*
 * Copyright (c) 2002-2006 by OpenSymphony
 * All rights reserved.
 */

package com.opensymphony.xwork2;

/**
 * Mock for an {@link ActionInvocation}.
 *
 * @author plightbo
 * @deprecated Please use @see com.opensymphony.xwork2.mock.MockActionInvocation instead
 */
@Deprecated public class MockActionInvocation extends com.opensymphony.xwork2.mock.MockActionInvocation {
}
