package com.opensymphony.xwork2.interceptor;

/**
 * <code>ValidationWorkflowAware</code>
 */
public interface ValidationWorkflowAware {

    String getInputResultName();
}
