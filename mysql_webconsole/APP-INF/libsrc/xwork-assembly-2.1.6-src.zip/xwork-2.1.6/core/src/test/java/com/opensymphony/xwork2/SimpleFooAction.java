/*
 * Copyright (c) 2002-2003 by OpenSymphony
 * All rights reserved.
 */
package com.opensymphony.xwork2;


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision: 1063 $
 */
public class SimpleFooAction implements Action {

    public String execute() throws Exception {
        return SUCCESS;
    }
}
