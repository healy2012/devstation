/*
 * Copyright (c) 2002-2003 by OpenSymphony
 * All rights reserved.
 */
package com.opensymphony.xwork2.util;

public enum FurColor {
    BROWN, BLACK, GREEN
}
