/*
 * Copyright (c) 2002-2003 by OpenSymphony
 * All rights reserved.
 */
package com.opensymphony.xwork2.util;


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision: 1063 $
 */
public class Owner {

    private Dog dog;


    public void setDog(Dog dog) {
        this.dog = dog;
    }

    public Dog getDog() {
        return dog;
    }
}
